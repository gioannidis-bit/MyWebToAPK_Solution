using MyWebToAPK.Helpers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace MyWebToAPK.Controllers
{
    public class HomeController : Controller
    {
        // Path to your pre-built base APK.
        private readonly string _baseApkPath = @"C:\Users\geori\source\repos\MyWebToAPK_Solution\BaseAPK\com.hit.MyMauiTemplateProject-Signed.apk";

        // GET: /Home/Index
        public IActionResult Index()
        {
            return View();
        }

        // POST: /Home/GenerateAPK
        [HttpPost]
        public async Task<IActionResult> GenerateAPK(string url, string apkName)
        {
            // Validate input.
            if (string.IsNullOrWhiteSpace(url))
            {
                ViewBag.Message = "URL is required.";
                return View("Index");
            }
            if (!Uri.TryCreate(url, UriKind.Absolute, out _))
            {
                ViewBag.Message = "Please enter a valid URL.";
                return View("Index");
            }
            if (string.IsNullOrWhiteSpace(apkName))
            {
                ViewBag.Message = "APK file name is required.";
                return View("Index");
            }
            if (!File.Exists(_baseApkPath))
            {
                ViewBag.Message = "Base APK file not found.";
                return View("Index");
            }

            try
            {
                // Copy the base APK to a temporary file.
                string tempApkPath = Path.Combine(Path.GetTempPath(), $"Custom_{Guid.NewGuid()}.apk");
                File.Copy(_baseApkPath, tempApkPath, true);

                // Update the APK's internal configuration (using your existing ApkHelper).
                bool updated = await ApkHelper.UpdateApkConfigAsync(tempApkPath, url);
                if (!updated)
                {
                    ViewBag.Message = "Failed to update the APK configuration.";
                    return View("Index");
                }

                // Extract the embedded keystore file.
                string keystoreResourceName = "MyWebToAPK.Tools.my-release-key.keystore"; // Adjust if necessary.
                string extractedKeystorePath = EmbeddedResourceHelper.ExtractResourceToTempFile(keystoreResourceName);
                Debug.WriteLine("Extracted keystore path: " + extractedKeystorePath);
                if (!File.Exists(extractedKeystorePath))
                {
                    ViewBag.Message = "Keystore file not found after extraction.";
                    return View("Index");
                }

                // Define keystore credentials.
                string keyAlias = "myalias";
                string keystorePass = "YourStorePassword"; // Replace with your actual store password.
                string keyPass = "YourKeyPassword";          // Replace with your actual key password.

                // Re-sign the APK using the signing helper.
                bool signed = await ApkSignerHelper.SignApkAsync(tempApkPath, extractedKeystorePath, keyAlias, keystorePass, keyPass);
                if (!signed)
                {
                    ViewBag.Message = "Failed to re-sign the APK.";
                    return View("Index");
                }

                // Clean up the extracted keystore file.
                if (File.Exists(extractedKeystorePath))
                    File.Delete(extractedKeystorePath);

                // Return the signed APK as a download.
                byte[] fileBytes = await File.ReadAllBytesAsync(tempApkPath);
                File.Delete(tempApkPath);
                return base.File(fileBytes, "application/vnd.android.package-archive", apkName);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in GenerateAPK: " + ex.Message);
                ViewBag.Message = "An error occurred while generating the APK.";
                return View("Index");
            }
        }
    }
}
