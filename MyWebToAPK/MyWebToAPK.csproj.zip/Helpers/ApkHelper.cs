﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MyWebToAPK.Helpers
{
    public static class EmbeddedResourceHelper
    {
        public static string ExtractResourceToTempFile(string resourceName)
        {
            string tempPath = Path.Combine(Path.GetTempPath(), Path.GetFileName(resourceName));
            var assembly = Assembly.GetExecutingAssembly();
            using (var resourceStream = assembly.GetManifestResourceStream(resourceName))
            {
                if (resourceStream == null)
                    throw new Exception($"Resource '{resourceName}' not found.");
                using (var fileStream = new FileStream(tempPath, FileMode.Create, FileAccess.Write))
                {
                    resourceStream.CopyTo(fileStream);
                }
            }
            return tempPath;
        }
    }

    public static class ApkHelper
    {
        public static async Task<bool> UpdateApkConfigAsync(string apkPath, string newUrl)
        {
            try
            {
                // Open the APK archive in update mode.
                using (ZipArchive archive = ZipFile.Open(apkPath, ZipArchiveMode.Update))
                {
                    // Find the entry for config.json (adjust the path if needed)
                    var entry = archive.GetEntry("assets/Resources/Assets/config.json");
                    if (entry != null)
                    {
                        // Read the current content.
                        string content;
                        using (var reader = new StreamReader(entry.Open()))
                        {
                            content = await reader.ReadToEndAsync();
                        }

                        // Deserialize, update, then serialize back.
                        var config = JsonSerializer.Deserialize<Dictionary<string, string>>(content);
                        if (config == null)
                        {
                            config = new Dictionary<string, string>();
                        }
                        config["url"] = newUrl;
                        string newContent = JsonSerializer.Serialize(config);

                        // Delete the old entry and create a new one.
                        entry.Delete();
                        var newEntry = archive.CreateEntry("assets/Resources/Assets/config.json");
                        using (var writer = new StreamWriter(newEntry.Open(), Encoding.UTF8))
                        {
                            await writer.WriteAsync(newContent);
                        }
                        return true;
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                // You can log the exception if needed.
                return false;
            }
        }
    }
}
